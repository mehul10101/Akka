package org.example;

import akka.actor.typed.ActorSystem;

public class Main {
    public static void main(String[] args) {
        ActorSystem<NumberOfPrimesBehaviour.Command> numberOfPrimes = ActorSystem.create(NumberOfPrimesBehaviour.create(), "numOfPrimes");
        numberOfPrimes.tell(new NumberOfPrimesBehaviour.InstructionCommand("start"));
    }
}
package org.example;

import java.io.Serializable;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

public class NumOfPrimesWorkerBehaviour extends AbstractBehavior<NumOfPrimesWorkerBehaviour.Command>{
    public NumOfPrimesWorkerBehaviour(ActorContext<Command> context) {
        super(context);
    }

    public static Behavior<Command> create() {
        return Behaviors.setup(NumOfPrimesWorkerBehaviour::new);
    }

    @Override
    public Receive<Command> createReceive() {
        return newReceiveBuilder()
                .onMessage(Command.class, cmd -> {
                    cmd.getSender().tell(new NumberOfPrimesBehaviour.ResultCommand(getNumberOfPrimes(cmd.getLoopNum())));
                    return this;
                })
                .build();
    }

    private int getNumberOfPrimes(int loopNum) {
        int numOfPrimes = 0, iterator, st = loopNum * 10000000;
        int end = st + 10000000;
        for (iterator = st; iterator < end; iterator++) {
            numOfPrimes = isPrimeOptimised(iterator) ? numOfPrimes + 1 : numOfPrimes;
        }
        return numOfPrimes;
    }

    private boolean isPrimeOptimised(int num) {
        if (num < 2) {
            return false;
        }
        if (num == 2) {
            return true;
        }
        if (num % 2 == 0) {
            return false;
        }
        for (int i = 3; i <= Math.sqrt(num); i += 2) {
            if (num % i == 0) {
                return false;
            }
        }

        return true;
    }

    public static class Command implements Serializable {

        private static final long serialVersionUID = 1L;

        private String message;
        private ActorRef<NumberOfPrimesBehaviour.Command> sender;
        private int loopNum;

        public Command(String message, int loopNum, ActorRef<NumberOfPrimesBehaviour.Command> sender) {
            this.message = message;
            this.loopNum = loopNum;
            this.sender = sender;
        }


        public String getMessage() {
            return message;
        }

        public int getLoopNum() {
            return loopNum;
        }

        public ActorRef<NumberOfPrimesBehaviour.Command> getSender() {
            return sender;
        }

    }
}

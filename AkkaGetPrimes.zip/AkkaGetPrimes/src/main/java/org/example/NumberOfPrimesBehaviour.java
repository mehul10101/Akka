package org.example;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

import java.io.Serializable;

public class NumberOfPrimesBehaviour extends AbstractBehavior<NumberOfPrimesBehaviour.Command> {

    private int numOfChildActorResults = 0;
    private int numberOfPrimes = 0;
    public NumberOfPrimesBehaviour(ActorContext<Command> context) {
        super(context);
    }

    public static Behavior<Command> create() {
        return Behaviors.setup(NumberOfPrimesBehaviour::new);
    }

    @Override
    public Receive<Command> createReceive() {
        long st = System.currentTimeMillis();
        return newReceiveBuilder()
                .onMessage(InstructionCommand.class, cmd -> {
                    if ("start".equals(cmd.getMessage())) {
                        for (int i = 0; i < 10; i++) {
                            ActorRef<NumOfPrimesWorkerBehaviour.Command> actorRef
                                    = getContext().spawn(NumOfPrimesWorkerBehaviour.create(), "worker" + i);
                            actorRef.tell(new NumOfPrimesWorkerBehaviour.Command("start", i, getContext().getSelf()));
                        }
                    }
                    return this;
                })
                .onMessage(ResultCommand.class, cmd -> {
                    numOfChildActorResults++;
                    numberOfPrimes += cmd.getNumberOfPrimes();
                    if (numOfChildActorResults == 10) {
                        System.out.println("number of primes: " + numberOfPrimes);
                        System.out.println(System.currentTimeMillis() - st + " millis");
                    }
                    return this;
                })
                .build();
    }

    public interface Command extends Serializable {
    }

    public static class InstructionCommand implements Command {
        private static final long serialVersionUID = 1L;
        private String message;

        public  InstructionCommand(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }

    public static class ResultCommand implements Command {
        private static final long serialVersionUID = 1L;
        private int numberOfPrimes;

        public ResultCommand(int numberOfPrimes) {
            this.numberOfPrimes = numberOfPrimes;
        }

        public int getNumberOfPrimes() {
            return numberOfPrimes;
        }

    }

}
